let databus = { scene: 'HOME', heroId: null };
export default databus;