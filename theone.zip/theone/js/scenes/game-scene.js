export default function drawGameScene(ctx) {
  ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
  ctx.fillStyle = '#111';
  ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

  ctx.fillStyle = '#fff';
  ctx.font = '28px Arial';
  ctx.fillText('游戏页面 (占位)', 100, 200);
}
