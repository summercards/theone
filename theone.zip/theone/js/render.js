import SceneManager from './engine/scene.js';
import drawGameScene from './scenes/game-scene.js';
import drawHeroSelect from './scenes/hero-select.js';

export default function render(ctx) {
  const scene = SceneManager.getScene();
  if (scene === 'HERO_SELECT') drawHeroSelect(ctx);
  else if (scene === 'GAME') drawGameScene(ctx);
}
