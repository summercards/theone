Page({
  startGame() {
    wx.navigateTo({
      url: '/pages/game/game'
    });
  }
});